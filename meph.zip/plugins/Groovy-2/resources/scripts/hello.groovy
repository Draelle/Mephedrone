// A simple script to demonstrate the GATE Groovy script PR
// Print a line to stdout for each document

println "hello world, ${doc.getName()}"